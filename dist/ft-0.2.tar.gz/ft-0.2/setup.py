from distutils.core import setup

setup(name="ft",
        version="0.2",
        description="Data management and manipulation package.",
        author="Dan Simonson",
        author_email="dan.simonson@gmail.com",
        url="http://www.thedansimonson.com/ft/",
        packages=["ft"],
        )
